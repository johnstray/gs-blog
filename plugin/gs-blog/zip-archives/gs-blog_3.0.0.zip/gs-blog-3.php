<?php
$thisfile = basename(__FILE__, ".php");
define('BLOGFILE', $thisfile);
define('BLOGPLUGINNAME', i18n_r(BLOGFILE.'/PLUGIN_TITLE'));
require_once("gs-blog-3/inc/common.php");

# add in this plugin's language file
if(file_exists(BLOGSETTINGS))
{
	$settings_lang = getXML(BLOGSETTINGS);
	$GSBLOGLANG = $settings_lang->lang;
}
else
{
	$GSBLOGLANG = "en_US";
}
i18n_merge($thisfile) || i18n_merge($GSBLOGLANG);

# register plugin
register_plugin(
	$thisfile, // ID of plugin, should be filename minus php
	i18n_r(BLOGFILE.'/PLUGIN_TITLE'), 	
	'3.0rc1', 		
	'JohnStray.com',
	'https://www.johnstray.com/get-simple/plugins/blog/', 
	i18n_r(BLOGFILE.'/PLUGIN_DESC'),
	'blog',
	'blog_admin_controller'  
);
add_action('nav-tab','createNavTab',array('blog',$thisfile,'Blog', 'manage'));
add_action('blog-sidebar','createSideMenu',array($thisfile, 'View Posts','manage'));
add_action('blog-sidebar','createSideMenu',array($thisfile, 'Create Post','create_post'));
add_action('blog-sidebar','createSideMenu',array($thisfile, 'Categories','categories'));
add_action('blog-sidebar','createSideMenu',array($thisfile, 'RSS Feeds','auto_importer'));
add_action('blog-sidebar','createSideMenu',array($thisfile, 'Custom Fields','custom_fields'));
add_action('blog-sidebar','createSideMenu',array($thisfile, 'Settings','settings'));
add_action('blog-sidebar','createSideMenu',array($thisfile, 'Help','help'));
add_action('index-pretemplate', 'set_blog_title', array() );

/** 
* Handles conditionals for admin functions
* 
* @return void
*/  
function blog_admin_controller()
{
	$Blog = new Blog;
	getBlogUserPermissions();
	global $blogUserPermissions;
?>
<div style="width:100%;margin:0 -15px -20px 0;padding:0px;position:relative;">
<div style="position:absolute;width:80px;top:0px;right:0px;font-size:10px;text-align:center;color:#666;line-height:12px;">GetSimple Blog<br /><span style="color:#ccc;">Version 3.0rc1</span><br /><br /></div>
<?php
	if (isset($_GET['manage'])) { ?>
    <h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/MANAGE_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/MANAGE_DESC'); ?></p>
  <?php } else if (isset($_GET['create_post'])) { ?>
		<h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/CREATE_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/CREATE_DESC'); ?></p>
  <?php } else if (isset($_GET['categories'])) { ?>
		<h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/CATEGORIES_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/CATEGORIES_DESC'); ?></p>
  <?php } else if (isset($_GET['auto_importer'])) { ?>
  	<h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/RSSFEEDS_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/RSSFEEDS_DESC'); ?></p>
  <?php } else if (isset($_GET['custom_fields'])) { ?>
  	<h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/CUSTF_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/CUSTF_DESC'); ?></p>
  <?php } else if (isset($_GET['settings'])) { ?>
  	<h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/SETTINGS_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/SETTINGS_DESC'); ?></p>
  <?php } else if (isset($_GET['help'])) { ?>
  	<h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/HELP_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/HELP_DESC'); ?></p>
  <?php } else { ?>
		<h3 class="floated" style="float:left"><?php i18n(BLOGFILE.'/PLUGIN_TITLE'); ?></h3>
    <p class="clear" style="color:#666;"><?php i18n(BLOGFILE.'/PLUGIN_DESC'); ?></p>
  <?php } ?>
</div></div>
<div class="main" style="margin-top:-10px;"><?php

	if(isset($_GET['edit_post']) && $blogUserPermissions['blogeditpost'] == true)
	{
		editPost($_GET['edit_post']);
	}
	elseif(isset($_GET['create_post']) && $blogUserPermissions['blogcreatepost'] == true)
	{
		editPost();
	}
	elseif(isset($_GET['categories']) && $blogUserPermissions['blogcategories'] == true)
	{
		if(isset($_GET['edit_category']))
		{
			$add_category = $Blog->saveCategory($_POST['new_category']);
			if($add_category == true)
			{
				echo '<div class="updated">';
				i18n(BLOGFILE.'/CATEGORY_ADDED');
				echo '</div>';
			}
			else
			{
				echo '<div class="error">';
				i18n(BLOGFILE.'/CATEGORY_ERROR');
				echo '</div>';
			}
		}
		if(isset($_GET['delete_category']))
		{
			$Blog->deleteCategory($_GET['delete_category']);
		}
		edit_categories();
	}
	elseif(isset($_GET['auto_importer']) && $blogUserPermissions['blogrssimporter'] == true)
	{
		if(isset($_POST['post-rss']))
		{
			$post_data = array();
			$post_data['name'] = $_POST['post-rss'];
			$post_data['category'] = $_POST['post-category'];
			$add_feed = $Blog->saveRSS($post_data);
			if($add_feed == true)
			{
				echo '<div class="updated">';
				i18n(BLOGFILE.'/FEED_ADDED');
				echo '</div>';
			}
			else
			{
				echo '<div class="error">';
				i18n(BLOGFILE.'/FEED_ERROR');
				echo '</div>';
			}
		}
		elseif(isset($_GET['delete_rss']))
		{
			$delete_feed = $Blog->deleteRSS($_GET['delete_rss']);
			if($delete_feed == true)
			{
				echo '<div class="updated">';
				i18n(BLOGFILE.'/FEED_DELETED');
				echo '</div>';
			}
			else
			{
				echo '<div class="error">';
				i18n(BLOGFILE.'/FEED_DELETE_ERROR');
				echo '</div>';
			}
		}
		edit_rss();
	}
	elseif(isset($_GET['settings']) && $blogUserPermissions['blogsettings'] == true)
	{
		show_settings_admin();
	}
	elseif(isset($_GET['help']) && $blogUserPermissions['bloghelp'] == true)
	{
		show_help_admin();
	}
	elseif(isset($_GET['custom_fields']) && $blogUserPermissions['blogcustomfields'] == true)
	{
		$CustomFields = new customFields;
		if(isset($_POST['save_custom_fields']))
		{
			$saveCustomFields = $CustomFields->saveCustomFields();
			if($saveCustomFields)
			{
				echo '<div class="updated">'.i18n_r(BLOGFILE.'/EDIT_OK').'</div>';
			}
		}
		show_custom_fields();
	}
	else
	{
		if(isset($_GET['save_post']))
		{
			savePost();
		}
		elseif(isset($_GET['delete_post']) && $blogUserPermissions['blogdeletepost'] == true)
		{
			$post_id = urldecode($_GET['delete_post']);
			$delete_post = $Blog->deletePost($post_id);
			if($delete_post == true)
			{
				echo '<div class="updated">';
				i18n(BLOGFILE.'/POST_DELETED');
				echo '</div>';
			}
			else
			{
				echo '<div class="error">';
				i18n(BLOGFILE.'/FEED_DELETE_ERROR');
				echo '</div>';
			}
		}
		show_posts_admin();
	}
}
/** 
* Conditionals to display posts/search/archive/tags/category/importer on front end of website
* 
* @return void
*/  
function blog_display_posts() 
{
	GLOBAL $content, $blogSettings, $data_index;
	
	$Blog = new Blog;
	$slug = base64_encode(return_page_slug());
	$blogSettings = $Blog->getSettingsData();
	$blog_slug = base64_encode($blogSettings["blogurl"]);
	if($slug == $blog_slug)
	{
		$content = '';
		ob_start();
		if($blogSettings["displaycss"] == 'Y')
		{
			echo "<style>\n";
			echo $blogSettings["csscode"];
			echo "\n</style>";
		}
		switch(true)
		{
			case (isset($_GET['post']) == true) :
				$post_file = BLOGPOSTSFOLDER.$_GET['post'].'.xml';
				show_blog_post($post_file);
				break;
			case (isset($_POST['search_blog']) == true) :
				search_posts($_POST['keyphrase']);
				break;
			case (isset($_GET['archive']) == true) :
				$archive = $_GET['archive'];
				show_blog_archive($archive);
				break;
			case (isset($_GET['tag']) == true) :
				$tag = $_GET['tag'];
				show_blog_tag($tag);
				break;
			case (isset($_GET['category']) == true) :
				$category = $_GET['category'];      
				show_blog_category($category);	
				break;
			case (isset($_GET['import'])) :
				auto_import();
				break;
			default :
				show_all_blog_posts();
				break;
		}
		$content = ob_get_contents();
	    ob_end_clean();		
	}
		return $content; // legacy support for non filter hook calls to this function
}

/** 
* Function to set Page Title to Post Title
* 
* @return void
*/
function set_blog_title () { 
	global $title, $blogSettings, $post;
	$slug = base64_encode(return_page_slug());
	if($slug == base64_encode($blogSettings["blogurl"])) {
		if(isset($_GET['post']) && !empty($post)) {
			$title = (string) $post->title;
		} else if (isset($_GET['archive'])) {
			$title = (string) i18n_r(BLOGFILE.'/ARCHIVE_PRETITLE').date('F Y',strtotime($_GET['archive']));
		} else if (isset($_GET['category'])) {
			$title = (string) i18n_r(BLOGFILE.'/CATEGORY_PRETITLE').$_GET['category'];
		}
	}
	$title = strip_tags(strip_decode($title));
}
